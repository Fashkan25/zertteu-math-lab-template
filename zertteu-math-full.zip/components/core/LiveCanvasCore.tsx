
export default function LiveCanvasCore(){
 return <div style={{color:'white'}}>Canvas Core Placeholder</div>;
}
