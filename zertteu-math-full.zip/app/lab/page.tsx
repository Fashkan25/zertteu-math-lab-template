
export default function LabMap(){
 const modules=[
  {title:'Тірі формула (Fit)', link:'/lab/live'},
  {title:'Escape Room', link:'/lab/escape'},
  {title:'AI Duel Arena', link:'/lab/duel'},
  {title:'Experiment Machine', link:'/lab/experiment'},
  {title:'Algorithm Builder', link:'/lab/builder'}
 ];
 return (
  <div className='p-6 max-w-4xl mx-auto space-y-6'>
    <h1 className='text-3xl font-bold'>Зертханалар картасы</h1>
    <div className='grid md:grid-cols-3 gap-4'>
      {modules.map((m,i)=>(
        <a key={i} href={m.link} className='p-4 rounded-xl bg-lab-panel border border-lab-grid hover:border-lab-yellow'>
          <h2 className='text-xl'>{m.title}</h2>
          <p className='text-sm text-lab-muted mt-2'>Кіру →</p>
        </a>
      ))}
    </div>
  </div>
 );
}